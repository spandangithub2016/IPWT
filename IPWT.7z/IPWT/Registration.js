
	function readURLPic(input)
	{      
        alert("Hi");
        if (input.files && input.files[0])
        {
            var reader = new FileReader();
            reader.onload = function (e)
            {
                $('#pic')
                    .attr('src', e.target.result);
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
    function readURLSign(input)
    {
        if (input.files && input.files[0])
        {
            var reader = new FileReader();
            reader.onload = function (e)
            {
                $('#sign')
                    .attr('src', e.target.result);
            };
            reader.readAsDataURL(input.files[0]);
        }
    }

function ValidateContactForm()
{
    
    var _phn 	 =   document.ContactForm.phone;
    var _email 	 =   document.ContactForm.email;
    var _gender	 =   document.ContactForm.gender;
    var _country =   document.ContactForm.country;
    var _cname   =   document.ContactForm.course;
    var _pic     =   document.ContactForm.pic;
    var _sign    =   document.ContactForm.sign;

    if(_pic.selectedIndex<1)
    {
        window.alert("Please enter Valid phone number");
        _pic.focus();
        return false;
    }

    if( _gender.selectedIndex<1 || _gender.value=="--Select--")
    {
        window.alert("Please select your Gender...");
        _gender.focus();
        return false;
    }


    if (_email.value == "")
    {
        window.alert("Please enter a valid e-mail address...");
        _email.focus();
        return false;
    }
    if (_email.value.indexOf("@", 0) < 0)
    {
        window.alert("Please enter a valid e-mail address...");
        _email.focus();
        return false;
    }
    if (_email.value.indexOf(".", 0) < 0)
    {
        window.alert("Please enter a valid e-mail address...");
        _email.focus();
        return false;
    }

    if(_cname.selectedIndex <1 || _cname.value==" ")
    {
    	window.alert("Please Enter Course Name as you want ");
    	_cname.focus();
    	return false;
    }   

    if(_country.selectedIndex < 1 || _country.value=="--Select--")
    {
        window.alert("Please select your Country...");
        _country.focus();
        return false;
    }

    var phoneno = /^\d{10}$/ ;
    if (_phn.value.match(phoneno))
    {
    	return true;
    }
    else
    {
    	window.alert("Please enter Valid phone number");
    	_phn.focus();
        return false;
    }

    
    return true;
}

function delivery(x)
{
      var coursename = x.value;

      if(coursename=="Msc")
      {
      	ContactForm.cid.value="MSC101";
      	ContactForm.fees.value="30,000 (INR)";
      	ContactForm.duration.value="2 Years";
      }
      else if(coursename=="MCA")
      {
      	ContactForm.cid.value="MCA102";
      	ContactForm.fees.value="45,000 (INR)";
      	ContactForm.duration.value="3 Years";
      }
      else if(coursename=="M.Tech")
      {
      	ContactForm.cid.value="MT103";
      	ContactForm.fees.value="20,000 (INR)";
      	ContactForm.duration.value="2 Years";
      }
      else if(coursename=="Phd")
      {
      	ContactForm.cid.value="PHD104";
      	ContactForm.fees.value="50,000 (INR)";
      	ContactForm.duration.value="5 Years";
      }
      else
      {
      	ContactForm.cid.value="";
      	ContactForm.fees.value="";
      	ContactForm.duration.value="";
      }
}
