<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="Reg.css">
<script type="text/javascript" src="Registration.js" ></script>
<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
	
	<!--Enable disable function in JQuery-->
	<script type="text/javascript">
    	$(document).ready(function(){
        	$('form input[type="text"]').prop("disabled", true);
        	$('form input[id="btn2"]').hide();
        		
        	$(".edit").click(function(){
        		$('form input[type="text"]').prop("disabled", false);
        		$('form input[id="btn2"]').show();
        	});
    	});
    
	</script>

</head>
<body>
<!-- storing Data from input fields-->
<?php
	$fname=$_REQUEST["fname"];
	$lname=$_REQUEST["lname"];
	$address=$_REQUEST["address"];
	$dob=$_REQUEST["dob"];
	$gender=$_REQUEST["gender"];
	$contact=$_REQUEST["phone"];
	$email=$_REQUEST["email"];
	$city=$_REQUEST["city"];
	$state=$_REQUEST["state"];
	$country=$_REQUEST["country"];
	$cname=$_REQUEST["course"];
	$cid=$_REQUEST["cid"];
	$fess=$_REQUEST["fees"];
	$duration=$_REQUEST["duration"];
?>
<!--To insert Data to the Database-->
<script>
	function insertData()
	{
	<?php
		$servername="localhost";
		$username="root";
		$password="wampstak";
		$dbname="myproject";

		$conn= new mysqli($servername,$username,$password,$dbname);

		if($conn->connect_error)
		{
			die("error connecting to database".$conn->connect_error);
		}
		else
		{
			echo "Connection Made";
		}

		$sql="INSERT INTO reg_details(firstname,lastname,address,dob,gender,contact,email,city,state,country,course_name)VALUES('$fname','$lname','$address','$dob','$gender','contact','$email','$city','$state','$country','$cname')"; 

		if ($conn->query($sql) === True) 
		{	
			echo "<br>New record created successfully";
		}	 
		else 
		{
			echo "error".$conn‐>error;
		}	
		$conn->close();
	?>
}
</script>
	
	<!--HTML CODE-->
	<center><h1  style="color: orange;">Your Form Details</h1></center>
	
	<form name="processForm" action="Result.htm" method="post">
		<label>Your First Name:</label>
			<input type="text" id="fname" name="firstname" value="<?php echo "$fname"; ?>" />
		<label>Your First Name:</label>
			<input type="text" name="lastname" value="<?php echo htmlentities($lname); ?>" />
		<label>Your Adress:</label>
			<input type="text" name="address" value="<?php echo "$address"; ?>"/><br>
		<label>Your Date-of-Birth:</label>
			<input type="text" name="dob" value="<?php echo htmlentities($dob); ?>" />
		<label>Your Gender:</label>
			<input type="text" name="firstname" value="<?php echo "$gender"; ?>" /><br>
		<label>Your Contact:</label>
			<input type="text" name="lastname" value="<?php echo htmlentities($contact); ?>" />
		<label>Your Email Id:</label>
			<input type="text" name="firstname" value="<?php echo "$email"; ?>" /><br>
		<label>Your City:</label>
			<input type="text" name="lastname" value="<?php echo htmlentities($city); ?>"  />	
		<label>Your State</label>
			<input type="text" name="firstname" value="<?php echo "$state"; ?>" /><br>
		<label>Your Country</label>
			<input type="text" name="lastname" value="<?php echo htmlentities($country); ?>"  />	
		<label>Your Course Name:</label>
			<input type="text" name="firstname" value="<?php echo "$cname"; ?>" /><br>
		<label>Your Course Id:</label>
			<input type="text" name="lastname" value="<?php echo htmlentities($cid); ?>"  />	
		<label>Your Course fees:</label>
			<input type="text" name="firstname" value="<?php echo "$fees"; ?>"  /><br>
		<label>Your Course Duration:</label>
			<input type="text" name="lastname" value="<?php echo htmlentities($duration); ?>"  />	<br><br><br><br>
		
		<input style="font-size: 25px;
			font-weight: bold;
    		width: 200px;
    		height: 35px;
    		background-color: #4CAF50;
    		color: white;
    		margin-right: 760px;
    		margin-top: 100px;
    		border: none;
    		border-radius: 4px;
    		cursor: pointer;" value="Edit" type="button" id="btn1" class="edit" />	
    	<input style="font-size: 25px;
			font-weight: bold;
    		width: 200px;
    		height: 35px;
    		background-color: #4CAF50;
    		color: white;
    		margin-right: 460px;
    		margin-top: -37px;
    		margin-bottom: 50px;
    		border: none;
    		border-radius: 4px;
    		cursor: pointer;" type="submit" id="btn2" value="Submit" onclick=" insertData(); " >
	</form>
</body>
</html>
